By downloading these data products, you have agreed to the licence terms and 
conditions as set out in each BC Data Catalogue metadata record.
Please ensure you understand the licences or contact one of the listed contacts for
more information.

If you need additional information about downloading data, please email data@gov.bc.ca. To report 
errors when downloading data please email NRSApplications@gov.bc.ca.

